/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/

/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	STORAGE_PLANNEREVENTSDB_ARN
	STORAGE_PLANNEREVENTSDB_NAME
	STORAGE_PLANNEREVENTSDB_STREAMARN
Amplify Params - DO NOT EDIT */

const AWS = require("aws-sdk");
const awsServerlessExpressMiddleware = require("aws-serverless-express/middleware");
const bodyParser = require("body-parser");
const express = require("express");

AWS.config.update({ region: process.env.TABLE_REGION });

const dynamodb = new AWS.DynamoDB.DocumentClient();

let tableName = "eventsTavle";
if (process.env.ENV && process.env.ENV !== "NONE") {
	tableName = tableName + "-" + process.env.ENV;
}

const userIdPresent = true; // TODO: update in case is required to use that definition
const partitionKeyName = "id";
const partitionKeyType = "S";
const sortKeyName = "userId";
const sortKeyType = "S";
const hasSortKey = sortKeyName !== "";
const path = "/events";
const UNAUTH = "UNAUTH";
const hashKeyPath = "/:" + partitionKeyName;
const sortKeyPath = hasSortKey ? "/:" + sortKeyName : "";

// declare a new express app
const app = express();
app.use(bodyParser.json());
app.use(awsServerlessExpressMiddleware.eventContext());

// Enable CORS for all methods
app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "*");
	next();
});

// convert url string param to expected Type
const convertUrlType = (param, type) => {
	switch (type) {
		case "N":
			return Number.parseInt(param);
		default:
			return param;
	}
};

/********************************
 * HTTP Get method for list objects *
 ********************************/

app.get(path + hashKeyPath, function(req, res) {
	const condition = {};
	condition[partitionKeyName] = {
		ComparisonOperator: "EQ",
	};

	if (userIdPresent && req.apiGateway) {
		condition[partitionKeyName]["AttributeValueList"] = [
			req.apiGateway.event.requestContext.identity.cognitoIdentityId || UNAUTH,
		];
	} else {
		try {
			condition[partitionKeyName]["AttributeValueList"] = [
				convertUrlType(req.params[partitionKeyName], partitionKeyType),
			];
		} catch (err) {
			res.statusCode = 500;
			res.json({ error: "Wrong column type " + err });
		}
	}

	let queryParams = {
		TableName: tableName,
		KeyConditions: condition,
	};

	dynamodb.scan(queryParams, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: "Could not load items: " + err });
		} else {
			res.json(data.Items);
		}
	});
});

//get method for get all events by userSub as param to filter by userId
app.get(path + "/filter/:userId", function(req, res) {
	const userId = req.params.userId;
	const params = {
		TableName: tableName,
		FilterExpression: "#userId = :userId",
		ExpressionAttributeNames: {
			"#userId": "userId",
		},
		ExpressionAttributeValues: {
			":userId": userId,
		},
	};

	dynamodb.scan(params, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: "Could not load items: " + err });
		} else {
			res.json(data.Items);
		}
	});
});

//get method for get all events by userSub as param to filter by userId,
//and optionally each of those: dayOfWeek, date, description,  if they are present
app.get(path + "/filter/:userId/:dayOfWeek/:date/:description", function(
	req,
	res,
) {
	const userId = req.params.userId;
	const dayOfWeek =
		req.params.dayOfWeek && req.params.dayOfWeek !== "null"
			? req.params.dayOfWeek
			: null;
	const date =
		req.params.date && req.params.date !== "null" ? req.params.date : null;
	const description =
		req.params.description && req.params.description !== "null"
			? req.params.description
			: null;
	const params = {
		TableName: tableName,
		FilterExpression: "#userId = :userId",
		ExpressionAttributeNames: {
			"#userId": "userId",
		},
		ExpressionAttributeValues: {
			":userId": userId,
		},
	};

	if (dayOfWeek) {
		params.FilterExpression += " and #dayOfWeek = :dayOfWeek";
		params.ExpressionAttributeNames["#dayOfWeek"] = "dayOfWeek";
		params.ExpressionAttributeValues[":dayOfWeek"] = dayOfWeek;
	}

	if (date) {
		params.FilterExpression += " and #date = :date";
		params.ExpressionAttributeNames["#date"] = "date";
		params.ExpressionAttributeValues[":date"] = date;
	}

	if (description) {
		params.FilterExpression += " and #description = :description";
		params.ExpressionAttributeNames["#description"] = "description";
		params.ExpressionAttributeValues[":description"] = description;
	}

	dynamodb.scan(params, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: "Could not load items: " + err });
		} else {
			res.json(data.Items);
		}
	});
});

/*****************************************
 * HTTP Get method for get single object *
 *****************************************/

app.get(path + "/object" + hashKeyPath + sortKeyPath, function(req, res) {
	const params = {};
	if (userIdPresent && req.apiGateway) {
		params[partitionKeyName] =
			req.apiGateway.event.requestContext.identity.cognitoIdentityId || UNAUTH;
	} else {
		params[partitionKeyName] = req.params[partitionKeyName];
		try {
			params[partitionKeyName] = convertUrlType(
				req.params[partitionKeyName],
				partitionKeyType,
			);
		} catch (err) {
			res.statusCode = 500;
			res.json({ error: "Wrong column type " + err });
		}
	}
	if (hasSortKey) {
		try {
			params[sortKeyName] = convertUrlType(
				req.params[sortKeyName],
				sortKeyType,
			);
		} catch (err) {
			res.statusCode = 500;
			res.json({ error: "Wrong column type " + err });
		}
	}

	let getItemParams = {
		TableName: tableName,
		Key: params,
	};

	dynamodb.get(getItemParams, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: "Could not load items: " + err.message });
		} else {
			if (data.Item) {
				res.json(data.Item);
			} else {
				res.json(data);
			}
		}
	});
});

//get all events by filter: userId(required), dayOfWeek, description, date
app.get(path + "/filter", function(req, res) {
	const params = {};
	if (userIdPresent && req.apiGateway) {
		params[partitionKeyName] =
			req.apiGateway.event.requestContext.identity.cognitoIdentityId || UNAUTH;
	} else {
		params[partitionKeyName] = req.params[partitionKeyName];
		try {
			params[partitionKeyName] = convertUrlType(
				req.params[partitionKeyName],
				partitionKeyType,
			);
		} catch (err) {
			res.statusCode = 500;
			res.json({ error: "Wrong column type " + err });
		}
	}
	if (hasSortKey) {
		try {
			params[sortKeyName] = convertUrlType(
				req.params[sortKeyName],
				sortKeyType,
			);
		} catch (err) {
			res.statusCode = 500;
			res.json({ error: "Wrong column type " + err });
		}
	}

	let queryParams = {
		TableName: tableName,
		KeyConditions: params,
	};

	dynamodb.scan(queryParams, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: "Could not load items: " + err });
		} else {
			res.json(data.Items);
		}
	});
});

/************************************
 * HTTP put method for insert object *
 *************************************/

app.put(path, function(req, res) {
	if (userIdPresent) {
		req.body["userId"] =
			req.apiGateway.event.requestContext.identity.cognitoIdentityId || UNAUTH;
	}

	let putItemParams = {
		TableName: tableName,
		Item: req.body,
	};
	dynamodb.put(putItemParams, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: err, url: req.url, body: req.body });
		} else {
			res.json({ success: "put call succeed!", url: req.url, data: data });
		}
	});
});

/************************************
 * HTTP post method for insert object *
 *************************************/

app.post(path, function(req, res) {
	let putItemParams = {
		TableName: tableName,
		Item: req.body,
	};
	dynamodb.put(putItemParams, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: err, url: req.url, body: req.body });
		} else {
			res.json({ success: "post call succeed!", url: req.url, data: data });
		}
	});
});

/**************************************
 * HTTP remove method to delete object *
 ***************************************/
//delete event by userId necessary,
//then by dayOfWeek or eventId
app.delete(path + "/:userId/dayOfWeek/:dayOfWeek", function(req, res) {
	const params = {
		TableName: tableName,
		Key: {
			userId: req.params.userId,
			dayOfWeek: req.params.dayOfWeek,
		},
  };
  //scan to get all events by dayOfWeek and userId params and delete them
  let queryParams = {
    TableName: tableName,
    KeyConditions: params,
  };
  dynamodb.scan(queryParams, (err, data) => {
    if (err) {
      res.statusCode = 500;
      res.json({ error: "Could not load items: " + err });
    } else {
      if (data.Items.length > 0) {
        data.Items.forEach(element => {
          if (element.dayOfWeek == req.params.dayOfWeek) {
            let deleteParams = {
              TableName: tableName,
              Key: {
                userId: element.userId,
                id: element.id,
               
              },
            };
            dynamodb.delete(deleteParams, (err, data) => {
              if (err) {
                res.statusCode = 500;
                res.json({ error: err, url: req.url });
              } else {
                res.json({ success: "delete call succeed!", url: req.url, data: data });
              }
            });
          }
          
        });
      }
      else {
        res.json({ success: "delete call succeed!", url: req.url, data: data });
      }
    }
  });
    

});
//delete event by userId necessary and eventId
app.delete(path + "/:userId/id/:id", function(req, res) {
	const params = {
		TableName: tableName,
		Key: {
			userId: req.params.userId,
			id: req.params.id,
		},
	};

	dynamodb.delete(params, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.json({ error: err, url: req.url });
		} else {
			res.json({ success: "delete call succeed!", url: req.url, data: data });
		}
	});
});
//to call this request to delete by userId and id use this: /events/1234567890/id/1234567890 where 1234567890 is the userId and id

app.listen(3000, function() {
	console.log("App started");
});

// Export the app object. When executing the application local this does nothing. However,
// to port it to AWS Lambda we will create a wrapper around that will load the app from
// this file
module.exports = app;
